from django import forms
from .models import TeamMember


# Creates a form for adding/editing team members
class TeamMemberForm(forms.ModelForm):
    class Meta:
        model = TeamMember
        fields = ['first_name', 'last_name', 'phone_number', 'email', 'role']