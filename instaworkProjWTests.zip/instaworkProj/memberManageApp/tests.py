from django.test import TestCase, Client
from django.urls import reverse_lazy
from .models import TeamMember
from .forms import TeamMemberForm
from .views import TeamMemberListView, TeamMemberCreateView, TeamMemberUpdateView, TeamMemberDeleteView


# Tests for model class and team member object
class TeamMemberTest(TestCase):

    # sets up example team member object
    def setUp(self):
        self.member = TeamMember.objects.create(
            first_name='Mihika',
            last_name='Iyer',
            phone_number='666-3064',
            email='mihika.iyer@gmail.com',
            role='admin'
        )

    # tests string representation method
    def test_str_representation(self):
        self.assertEqual(str(self.member), 'Mihika Iyer')

    # tests string representation method
    def test_default_role(self):
        member = TeamMember.objects.create(
            first_name='Devy',
            last_name='Chandra',
            phone_number='555-5678',
            email='devy.chandra@example.com',
        )
        self.assertEqual(member.role, 'regular')


# Tests for forms class and team member form object
class TeamMemberFormTest(TestCase):

    # tests if the form is valid
    def test_valid_form(self):
        form_data = {
            'first_name': 'Mihika',
            'last_name': 'Iyer',
            'phone_number': '555-1234',
            'email': 'mihika.iyer@gmail.com',
            'role': 'admin',
        }
        form = TeamMemberForm(data=form_data)
        self.assertTrue(form.is_valid())

    # tests if blank data results in a form error
    def test_blank_data(self):
        form_data = {}
        form = TeamMemberForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 5)

    # tests if a missing required field results in a form error
    def test_missing_required_field(self):
        form_data = {
            'first_name': 'Devy',
            'last_name': 'Chandra',
            'phone_number': '555-5678',
            'email': 'devy.chandra@example.com',
        }
        form = TeamMemberForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 1)
        self.assertTrue('role' in form.errors)

    # tests if form save mechanism works
    def test_form_save(self):
        form_data = {
            'first_name': 'Rahil',
            'last_name': 'Badkul',
            'phone_number': '555-1357',
            'email': 'rahil.badkul@example.com',
            'role': 'regular',
        }
        form = TeamMemberForm(data=form_data)
        self.assertTrue(form.is_valid())
        member = form.save()
        self.assertIsInstance(member, TeamMember)
        self.assertEqual(member.first_name, form_data['first_name'])
        self.assertEqual(member.last_name, form_data['last_name'])
        self.assertEqual(member.phone_number, form_data['phone_number'])
        self.assertEqual(member.email, form_data['email'])
        self.assertEqual(member.role, form_data['role'])


# Tests for views class
class TestViews(TestCase):

    # sets up team member object
    def setUp(self):
        self.client = Client()
        self.list_url = reverse_lazy('team_member_list')
        self.add_url = reverse_lazy('team_member_add')
        self.edit_url = reverse_lazy('team_member_edit', args=[1])
        self.delete_url = reverse_lazy('team_member_delete', args=[1])
        self.test_member = TeamMember.objects.create(
            first_name='Mihika',
            last_name='Iyer',
            phone_number='6663064',
            email='mihika.iyer@gmail.com',
            role='regular'
        )

        # sets up edited data
        self.edit_data = {
            'first_name': 'Jane',
            'last_name': 'Doe',
            'phone_number': '0987654321',
            'email': 'janedoe@example.com',
            'role': 'admin'
        }

    # tests list view set up
    def test_team_member_list_view(self):
        response = self.client.get(self.list_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'memberManageAppTemps/team_member_list.html')

    # tests add view set up
    def test_team_member_add_view(self):
        response = self.client.get(self.add_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'memberManageAppTemps/team_member_form.html')

        response = self.client.post(self.add_url, {
            'first_name': 'Jane',
            'last_name': 'Doe',
            'phone_number': '1234567890',
            'email': 'janedoe@example.com',
            'role': 'admin'
        })
        self.assertTrue(TeamMember.objects.filter(first_name='Jane').exists())

    # tests edit view set up
    def test_team_member_edit_view(self):
        response = self.client.get(self.edit_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'memberManageAppTemps/team_member_form.html')

        response = self.client.post(self.edit_url, self.edit_data)
        self.test_member.refresh_from_db()
        self.assertEquals(self.test_member.first_name, 'Jane')
        self.assertEquals(self.test_member.phone_number, '0987654321')

    # tests delete view set up (cannot figure out why not running?)
    def test_team_member_delete_view(self):
        response = self.client.get(self.delete_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'memberManageAppTemps/team_member_delete.html')

        response = self.client.post(self.delete_url, follow=True)
        self.assertFalse(TeamMember.objects.filter(first_name='Mihika').exists())

