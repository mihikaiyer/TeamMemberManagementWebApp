from django.apps import AppConfig


class MembermanageappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'memberManageApp'
