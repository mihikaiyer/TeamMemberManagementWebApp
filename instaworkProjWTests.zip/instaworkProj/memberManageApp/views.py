from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import TeamMember
from .forms import TeamMemberForm


# Displays a list of all team members
class TeamMemberListView(ListView):
    model = TeamMember
    template_name = 'memberManageAppTemps/team_member_list.html'


# Displays a form to add a new team member
class TeamMemberCreateView(CreateView):
    model = TeamMember
    form_class = TeamMemberForm
    template_name = 'memberManageAppTemps/team_member_form.html'
    success_url = reverse_lazy('team_member_list')

# Displays a form to edit an existing team member
class TeamMemberUpdateView(UpdateView):
    model = TeamMember
    form_class = TeamMemberForm
    template_name = 'memberManageAppTemps/team_member_form.html'
    success_url = reverse_lazy('team_member_list')

# Displays a confirmation page to delete a team member
class TeamMemberDeleteView(DeleteView):
    model = TeamMember
    template_name = 'memberManageAppTemps/team_member_delete.html'
    success_url = reverse_lazy('team_member_list')

